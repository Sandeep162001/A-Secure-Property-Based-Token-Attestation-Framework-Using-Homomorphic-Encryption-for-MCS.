<%@ page import="java.util.*" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
    String cemail = (String) session.getAttribute("cemailid");
    List<Map<String, String>> files = (List<Map<String, String>>) request.getAttribute("files");
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Search File | Client Module</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }
        .card-glow:hover {
            transform: scale(1.07);
            box-shadow: 0 0 25px rgba(0,255,255,0.7);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- TITLE -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-6">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- SEARCH PAGE CARD -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-10 mt-10 
                w-full max-w-5xl shadow-2xl text-center">

        <h2 class="text-3xl font-bold text-cyan-300 mb-4">Search a File</h2>

        <% if (cemail != null) { %>
            <p class="text-xl mb-6">
                Logged in as 
                <span class="text-cyan-300 font-semibold"><%= cemail %></span>
            </p>
        <% } %>

        <!-- MODULES MENU -->
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">

            <a href="CHome.jsp" class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                Home
            </a>

            <a href="Search.jsp" class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                Search File
            </a>

            <a href="VFNames.jsp" class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                View File Names
            </a>

            <a href="viewkey.jsp" class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                View Decryption Keys
            </a>

            <a href="CLogin.jsp" class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-red-400 rounded-xl text-lg font-semibold text-red-300">
                Logout
            </a>

        </div>

        <!-- SEARCH INPUT -->
        <form action="Search" method="get" class="mt-10">
            <input type="text"
                   name="search"
                   placeholder="Enter keyword here..."
                   value="<%= request.getAttribute("keyword") != null ? request.getAttribute("keyword") : "" %>"
                   required
                   class="w-full md:w-2/3 p-3 bg-black/30 border border-cyan-300 rounded-lg glow-input text-white">
            <button type="submit"
                    class="mt-4 md:mt-0 md:ml-4 p-3 bg-cyan-500 text-black rounded-lg font-semibold hover:scale-105 transition">
                Search
            </button>
        </form>

        <!-- RESULTS TABLE -->
        <% 
            if (files != null && !files.isEmpty()) { 
        %>

        <div class="overflow-x-auto mt-10">
            <table class="w-full text-white border border-cyan-400 rounded-xl">
                <thead class="bg-cyan-500 text-black">
                    <tr>
                        <th class="p-3">Filename</th>
                        <th class="p-3">Email ID</th>
                        <th class="p-3">Token</th>
                        <th class="p-3">Upload Time</th>
                        <th class="p-3">Action</th>
                    </tr>
                </thead>

                <tbody>
                <%
                    for (Map<String, String> file : files) {
                %>
                    <tr class="bg-white/10 border-b border-cyan-300">
                        <td class="p-3"><%= file.get("filename") %></td>
                        <td class="p-3"><%= file.get("emailid") %></td>
                        <td class="p-3"><%= file.get("token") %></td>
                        <td class="p-3"><%= file.get("upload_time") %></td>

                        <td class="p-3">
                            <form method="post">
                                <input type="hidden" name="filename" value="<%= file.get("filename") %>">
                                <input type="hidden" name="encrypted_data" value="<%= file.get("encrypted_data") %>">
                                <input type="hidden" name="token" value="<%= file.get("token") %>">

                                <button type="submit" name="action" value="Show File"
                                        class="p-2 bg-cyan-500 text-black rounded-lg hover:scale-105 transition">
                                    Show File
                                </button>
                            </form>
                        </td>
                    </tr>
                <% } %>
                </tbody>
            </table>
        </div>

        <!-- SHOW ENCRYPTED DATA -->
        <%  
            String action = request.getParameter("action");
            if ("Show File".equals(action)) {
                String encData = request.getParameter("encrypted_data");
        %>

        <div class="mt-10 text-left">
            <h3 class="text-2xl font-bold text-cyan-300 mb-4 text-center">Encrypted Data</h3>

            <textarea rows="8"
                      class="w-full p-4 bg-black/30 border border-cyan-400 rounded-lg text-white"
                      readonly><%= encData %></textarea>

            <form action="RequestDecrypt" method="post" class="text-center mt-6">
                <input type="hidden" name="filename" value="<%= request.getParameter("filename") %>">
                <input type="hidden" name="encrypted_data" value="<%= encData %>">
                <input type="hidden" name="token" value="<%= request.getParameter("token") %>">

                <button type="submit"
                        class="p-3 bg-cyan-500 text-black rounded-lg font-semibold hover:scale-105 transition">
                    Request Decryption
                </button>
            </form>
        </div>

        <% } %>

        <% } else if (request.getAttribute("keyword") != null) { %>

            <p class="text-center text-xl text-red-300 mt-10">
                No approved files found matching 
                "<span class="text-white font-bold"><%= request.getAttribute("keyword") %></span>"
            </p>

        <% } %>

    </div>

    <footer class="text-center py-8 opacity-80 mt-14">
        <p>© 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>
</html>
