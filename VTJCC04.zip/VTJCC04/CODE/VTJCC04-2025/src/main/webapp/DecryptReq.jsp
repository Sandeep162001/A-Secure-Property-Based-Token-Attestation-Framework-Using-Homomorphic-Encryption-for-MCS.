<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.Time"%>
<%@page import="com.Db.Database"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Decryption Requests | Cloud Server</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }
        .card-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,255,255,0.6);
        }

        .table-container {
            max-height: 400px;
            overflow-y: auto;
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- Project Title -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-4">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- PAGE TITLE -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-8 mt-10 w-full max-w-3xl shadow-2xl text-center">
        <h2 class="text-4xl font-bold text-cyan-300">
            Decryption Requests
        </h2>
        <p class="text-lg opacity-90 mt-2">Manage decrypt key approvals securely</p>
    </div>

    <!-- MODULES SECTION -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10 px-4">

        <!-- HOME -->
        <a href="CSHome.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-green-400 rounded-xl 
                  text-xl font-semibold">
            Home
        </a>

        <!-- VIEW DECRYPTION REQUESTS -->
        <a href="DecryptReq.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 rounded-xl 
                  text-xl font-semibold">
            View Decryption Requests
        </a>

        <!-- LOGOUT -->
        <a href="CSLogin.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-red-400 rounded-xl 
                  text-xl font-semibold">
            Logout
        </a>

    </div>

    <!-- TABLE SECTION -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-8 mt-12 w-full max-w-6xl shadow-2xl">

        <div class="table-container">
            <table class="w-full text-center border-collapse text-white">
                <thead class="bg-cyan-600/40 font-bold text-lg">
                    <tr>
                        <th class="p-3 border border-cyan-500">Id</th>
                        <th class="p-3 border border-cyan-500">File Name</th>
                        <th class="p-3 border border-cyan-500">User Email</th>
                        <th class="p-3 border border-cyan-500">Client Email</th>
                        <th class="p-3 border border-cyan-500">Encrypted Data</th>
                        <th class="p-3 border border-cyan-500">Token</th>
                        <th class="p-3 border border-cyan-500">Request Time</th>
                        <th class="p-3 border border-cyan-500">Actions</th>
                    </tr>
                </thead>

                <tbody>
                <%
                    Connection connection = null;
                    PreparedStatement preparedStatement = null;
                    ResultSet resultSet = null;

                    try {
                        connection = Database.getconnection();
                        String sql = "SELECT * FROM decrypt_requests WHERE status='pending' AND secret_key='pending'";
                        preparedStatement = connection.prepareStatement(sql);
                        resultSet = preparedStatement.executeQuery();

                        while (resultSet.next()) {

                            int rid = resultSet.getInt("id");
                            String filename = resultSet.getString("filename");
                            String uemailid = resultSet.getString("uemailid");
                            String cemailid = resultSet.getString("cemailid");
                            String encrypted = resultSet.getString("encrypteddata");
                            String token = resultSet.getString("token");
                            Time reqTime = resultSet.getTime("request_time");
                %>
                    <tr class="bg-white/5 border-b border-gray-600">
                        <td class="p-3"><%= rid %></td>
                        <td class="p-3"><%= filename %></td>
                        <td class="p-3"><%= uemailid %></td>
                        <td class="p-3"><%= cemailid %></td>
                        <td class="p-3 break-all max-w-xs"><%= encrypted %></td>
                        <td class="p-3"><%= token %></td>
                        <td class="p-3"><%= reqTime %></td>

                        <td class="p-3">
                            <a href="DecryptReq.jsp?action=approve&id=<%= rid %>"
                               class="bg-green-500 px-4 py-2 rounded-lg font-semibold hover:bg-green-600">
                                Approve
                            </a>
                            <a href="DecryptReq.jsp?action=reject&id=<%= rid %>"
                               class="bg-red-500 px-4 py-2 rounded-lg font-semibold hover:bg-red-600 ml-3">
                                Reject
                            </a>
                        </td>
                    </tr>

                <%  
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (resultSet != null) resultSet.close();
                            if (preparedStatement != null) preparedStatement.close();
                            if (connection != null) connection.close();
                        } catch (SQLException e) { e.printStackTrace(); }
                    }

                    String action = request.getParameter("action");
                    String id = request.getParameter("id");

                    if (action != null && id != null) {
                        try {
                            connection = Database.getconnection();

                            if (action.equals("approve")) {
                                String updateSQL = "UPDATE decrypt_requests SET status='approved', secret_key='pending' WHERE id=?";
                                preparedStatement = connection.prepareStatement(updateSQL);
                                preparedStatement.setInt(1, Integer.parseInt(id));
                                preparedStatement.executeUpdate();
                                response.sendRedirect("DecryptReq.jsp");

                            } else if (action.equals("reject")) {
                                String deleteSQL = "UPDATE decrypt_requests SET status='rejected', secret_key='rejected' WHERE id=?";
                                preparedStatement = connection.prepareStatement(deleteSQL);
                                preparedStatement.setInt(1, Integer.parseInt(id));
                                preparedStatement.executeUpdate();
                                response.sendRedirect("DecryptReq.jsp");
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                if (preparedStatement != null) preparedStatement.close();
                                if (connection != null) connection.close();
                            } catch (SQLException e) { e.printStackTrace(); }
                        }
                    }
                %>
                </tbody>
            </table>
        </div>

    </div>

    <footer class="text-center py-10 opacity-80">
        © 2025 Secure Token Attestation Framework | Cloud Server
    </footer>

</body>
</html>
