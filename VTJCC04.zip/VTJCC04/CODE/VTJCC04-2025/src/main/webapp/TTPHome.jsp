<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>TTP Home | Secure Token Attestation Framework</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }

        .card-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,255,255,0.6);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- PROJECT TITLE -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-4">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- WELCOME CARD -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-10 mt-10 w-full max-w-2xl shadow-2xl text-center">

        <h2 class="text-4xl font-bold text-cyan-300 mb-6">
            Welcome to Trusted Third Party Home
        </h2>

        <p class="text-lg opacity-80">
            Manage all user, client, and file verification requests securely using the PTA-HE framework.
        </p>

    </div>

    <!-- MODULES SECTION -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl 
                p-10 mt-10 w-full max-w-3xl shadow-2xl text-center">

        <h2 class="text-3xl font-bold text-cyan-300 mb-6">
            TTP Modules
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">

           
            <a href="index.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold">
                Home
            </a>
            
            <a href="URegReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold">
                User Registration Requests
            </a>

            <a href="UploadReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold">
                File Uploaded Requests
            </a>

            <a href="CRegReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold">
                Client Registration Requests
            </a>

            

            <a href="TTPLogin.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold text-red-300">
                Logout
            </a>

        </div>
    </div>

    <footer class="text-center py-8 opacity-80 mt-14">
        <p>© 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>
</html>
