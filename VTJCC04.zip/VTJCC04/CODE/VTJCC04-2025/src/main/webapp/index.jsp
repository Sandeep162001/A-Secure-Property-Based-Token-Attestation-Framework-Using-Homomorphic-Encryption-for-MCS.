<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>A Secure Property-Based Token Attestation Framework</title>

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        /* Hero Background Animation */
        .gradient-bg {
            background: linear-gradient(-45deg, #0f0f0f, #1a1a40, #162447, #1f4068);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        /* Glow Buttons */
        .glow-btn {
            transition: 0.3s;
        }

        .glow-btn:hover {
            box-shadow: 0px 0px 20px rgba(0, 255, 255, 0.7);
            transform: scale(1.08);
        }

        /* Card Hover */
        .module-card {
            transition: 0.3s;
        }

        .module-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 30px rgba(0, 255, 255, 0.4);
        }
    </style>
</head>

<body class="gradient-bg text-white font-sans">

    <!-- HEADER SECTION -->
    <header class="py-6 text-center">
        <h1 class="text-4xl md:text-5xl font-extrabold tracking-wide drop-shadow-lg">
            A Secure Property-Based Token Attestation Framework
        </h1>
        <p class="text-lg mt-4 opacity-80">
            Using Homomorphic Encryption for Mobile Cloud Systems
        </p>
    </header>

    <!-- HERO SECTION -->
    <section class="flex flex-col items-center justify-center py-16 px-6 text-center">
        <h2 class="text-3xl md:text-4xl font-bold mb-6">
            Welcome to Secure Cloud Attestation
        </h2>
        <p class="max-w-3xl text-lg opacity-90 mb-10">
            Experience secure, encrypted, and property-based token attestation ensuring
            trusted communication among User, Client, Cloud Server, and TTP.
        </p>

        <a href="#modules"
            class="glow-btn px-8 py-3 rounded-full bg-cyan-500 text-black font-semibold text-lg shadow-lg">
            Explore Modules ↓
        </a>
    </section>

    <!-- MODULE SECTION -->
    <section id="modules" class="py-20 px-10">
        <h2 class="text-center text-4xl font-bold mb-14">System Modules</h2>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

            <!-- USER -->
            <a href="URegistration.jsp"
                class="module-card bg-white/10 backdrop-blur-xl p-8 rounded-2xl border border-cyan-400 cursor-pointer">
                <h3 class="text-2xl font-bold mb-4 text-cyan-300">User</h3>
                <p class="opacity-80">
                    Register, login, request tokens, verify access, and interact securely with the client and cloud.
                </p>
            </a>

            <!-- CLIENT -->
            <a href="CRegistration.jsp"
                class="module-card bg-white/10 backdrop-blur-xl p-8 rounded-2xl border border-cyan-400 cursor-pointer">
                <h3 class="text-2xl font-bold mb-4 text-cyan-300">Client</h3>
                <p class="opacity-80">
                    Handles encryption, property-based validation, and communication with TTP and Cloud Server.
                </p>
            </a>

            <!-- CLOUD SERVER -->
            <a href="CSLogin.jsp"
                class="module-card bg-white/10 backdrop-blur-xl p-8 rounded-2xl border border-cyan-400 cursor-pointer">
                <h3 class="text-2xl font-bold mb-4 text-cyan-300">Cloud Server</h3>
                <p class="opacity-80">
                    Securely stores encrypted data and validates homomorphic operations under the attestation model.
                </p>
            </a>

            <!-- TTP -->
            <a href="TTPLogin.jsp"
                class="module-card bg-white/10 backdrop-blur-xl p-8 rounded-2xl border border-cyan-400 cursor-pointer">
                <h3 class="text-2xl font-bold mb-4 text-cyan-300">Trusted Third Party (TTP)</h3>
                <p class="opacity-80">
                    Core authority responsible for token generation and secure attestation verification.
                </p>
            </a>

        </div>
    </section>

    <!-- FOOTER -->
    <footer class="text-center py-8 opacity-80">
        <p>© 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>

</html>
