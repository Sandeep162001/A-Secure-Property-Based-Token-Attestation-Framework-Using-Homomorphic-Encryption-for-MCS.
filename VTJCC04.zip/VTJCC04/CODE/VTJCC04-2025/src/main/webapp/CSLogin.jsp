<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Cloud Server Login | Secure Token Attestation Framework</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        /* Background gradient animation */
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .glow-input:focus {
            outline: none;
            border-color: cyan;
            box-shadow: 0 0 12px cyan;
        }

        .card-glow {
            transition: 0.3s;
        }

        .card-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,255,255,0.6);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- Project Title -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-4">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- LOGIN CARD -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-10 mt-10 w-full max-w-xl shadow-2xl">

        <h2 class="text-center text-3xl font-bold text-cyan-300 mb-6">
            Cloud Server Login
        </h2>

        <!-- Cloud Server Login Form -->
        <form action="CSLogin" method="get" class="space-y-5">

            <input type="email" 
                   name="emailid"
                   placeholder="Enter Your Email ID" 
                   required
                   class="glow-input w-full p-3 rounded-lg bg-black/30 border border-gray-500">

            <input type="password" 
                   name="password"
                   placeholder="Enter Your Password" 
                   required
                   class="glow-input w-full p-3 rounded-lg bg-black/30 border border-gray-500">

            <button type="submit"
                    class="w-full p-3 mt-3 text-lg font-semibold bg-cyan-500 text-black rounded-lg hover:scale-105 hover:shadow-2xl transition">
                Login
            </button>
        </form>

    </div>

    <!-- MODULES SECTION -->
    <h2 class="text-center text-2xl font-bold text-cyan-300 mt-14">System Modules</h2>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8 px-4">

        <!-- Home -->
        <a href="index.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 rounded-xl text-xl font-semibold">
            Home
        </a>

        <!-- User -->
        <a href="ULogin.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 rounded-xl text-xl font-semibold">
            User
        </a>

        <!-- Client -->
        <a href="CLogin.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 rounded-xl text-xl font-semibold">
            Client
        </a>

        <!-- Cloud Server -->
        <a href="CSLogin.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 rounded-xl text-xl font-semibold">
            Cloud Server
        </a>

        <!-- TTP -->
        <a href="TTPLogin.jsp"
           class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 rounded-xl text-xl font-semibold">
            Trusted Third Party
        </a>

    </div>

    <br><br>
    <footer class="text-center py-8 opacity-80">
        <p>© 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>
</html>
