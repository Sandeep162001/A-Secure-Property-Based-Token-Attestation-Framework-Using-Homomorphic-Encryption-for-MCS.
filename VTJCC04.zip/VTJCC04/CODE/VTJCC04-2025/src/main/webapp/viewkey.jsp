<%@page import="java.sql.*"%>
<%@page import="com.Db.Database"%>
<%
    String cemail = (String) session.getAttribute("cemailid");
%>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Decryption Keys | Client Module</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }

        .card-glow:hover {
            transform: scale(1.07);
            box-shadow: 0 0 25px rgba(0,255,255,0.7);
        }

        table tr:hover {
            background-color: rgba(0,255,255,0.1);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- PROJECT TITLE -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-6">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- MAIN CARD -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-10 mt-10 
                w-full max-w-5xl shadow-2xl text-center">

        <h2 class="text-3xl font-bold text-cyan-300 mb-4">View Decryption Keys</h2>

        <% if (cemail != null) { %>
            <p class="text-2xl font-semibold text-white mb-6">
                Welcome, <span class="text-cyan-300"><%= cemail %></span>
            </p>
        <% } %>

        <!-- MODULES PANEL -->
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 mt-4 mb-10">

            <!-- HOME -->
            <a href="CHome.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                Home
            </a>

            <!-- SEARCH FILE -->
            <a href="Search.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                Search File
            </a>

            <!-- VIEW FILE NAMES -->
            <a href="VFNames.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                View File Names
            </a>

            <!-- VIEW DECRYPTION KEYS -->
            <a href="viewkey.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                View Decryption Keys
            </a>

            <!-- LOGOUT -->
            <a href="CLogin.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-red-400 rounded-xl text-lg font-semibold text-red-300">
                Logout
            </a>

        </div>

        <!-- FETCHING KEYS -->
        <%
            if (cemail == null) {
        %>
            <h3 class="text-red-300 text-xl font-bold">Please login first!</h3>
        <%
                return;
            }

            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                con = Database.getconnection();
                String sql = "SELECT * FROM decrypt_requests WHERE cemailid=? AND status='Key Issued'";
                ps = con.prepareStatement(sql);
                ps.setString(1, cemail);
                rs = ps.executeQuery();
        %>

        <!-- TABLE -->
        <div class="overflow-x-auto mt-6">
            <table class="w-full text-white border border-cyan-400 rounded-xl overflow-hidden">
                <thead class="bg-cyan-900">
                    <tr>
                        <th class="p-3">ID</th>
                        <th class="p-3">Filename</th>
                        <th class="p-3">User Email</th>
                        <th class="p-3">Token</th>
                        <th class="p-3">Secret Key</th>
                        <th class="p-3">Download</th>
                    </tr>
                </thead>

                <tbody class="bg-white/5">
                <%
                    while (rs.next()) {
                        int id = rs.getInt("id");
                        String filename = rs.getString("filename");
                        String useremailid = rs.getString("uemailid");
                        String token = rs.getString("token");
                        String skey = rs.getString("secret_key");
                %>

                    <tr class="border-b border-cyan-400">
                        <td class="p-3"><%= id %></td>
                        <td class="p-3"><%= filename %></td>
                        <td class="p-3"><%= useremailid %></td>
                        <td class="p-3"><%= token %></td>
                        <td class="p-3 text-cyan-300 font-semibold"><%= skey %></td>

                        <td class="p-3">
                            <form action="ViewKey" method="post">
                                <input type="hidden" name="filename" value="<%= filename %>">
                                <input type="hidden" name="token" value="<%= token %>">

                                <button type="submit"
                                    class="bg-cyan-600 hover:bg-cyan-700 px-4 py-2 rounded-lg font-semibold">
                                    Download File
                                </button>
                            </form>
                        </td>
                    </tr>

                <%
                    }
                %>
                </tbody>
            </table>
        </div>

        <%
            } catch (Exception e) {
                out.println("<p class='text-red-400 mt-4'>Error loading keys!</p>");
                e.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (Exception ex) {}
                try { if (ps != null) ps.close(); } catch (Exception ex) {}
                try { if (con != null) con.close(); } catch (Exception ex) {}
            }
        %>

    </div>

    <footer class="text-center py-8 opacity-80 mt-14">
        <p>� 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>
</html>
