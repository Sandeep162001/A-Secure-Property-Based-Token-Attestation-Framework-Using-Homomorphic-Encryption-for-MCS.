<%@page import="java.sql.Time"%>
<%@page import="java.sql.SQLException"%>
<%@page import="com.Db.Database"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
    String uemail = (String) session.getAttribute("uemailid");
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Decrypt Key Requests | Secure Token Attestation</title>

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }

        .card-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,255,255,0.6);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- Project Title -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-4">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- MAIN CONTENT CARD -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-10 mt-10
                w-full max-w-5xl shadow-2xl">

        <!-- Header -->
        <h2 class="text-3xl font-bold text-cyan-300 mb-6 text-center">
            View Decrypt Key Requests
        </h2>

        <% if (uemail != null) { %>
            <p class="text-xl font-semibold text-center text-white mb-6">
                Logged in as: <span class="text-cyan-300"><%= uemail %></span>
            </p>
        <% } %>

        <!-- MODULE BUTTONS -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">

            <a href="UHome.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center border border-cyan-400
               rounded-xl font-semibold">
                Home
            </a>

            <a href="Upload.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center border border-cyan-400
               rounded-xl font-semibold">
                Upload a File
            </a>

            <a href="KeyReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center border border-cyan-400
               rounded-xl font-semibold text-cyan-300">
                View Key Requests
            </a>

            <a href="ULogin.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center border border-cyan-400
               rounded-xl font-semibold text-red-400">
                Logout
            </a>

        </div>

        <!-- TABLE SECTION -->
        <div class="overflow-x-auto">
            <table class="min-w-full border border-cyan-400 bg-white/10 backdrop-blur-xl rounded-xl text-white">
                <thead>
                    <tr class="bg-cyan-900/40 text-cyan-300">
                        <th class="p-3 border border-cyan-700">ID</th>
                        <th class="p-3 border border-cyan-700">File Name</th>
                        <th class="p-3 border border-cyan-700">Client Email</th>
                        <th class="p-3 border border-cyan-700">Encrypted Data</th>
                        <th class="p-3 border border-cyan-700">Token</th>
                        <th class="p-3 border border-cyan-700">Status</th>
                        <th class="p-3 border border-cyan-700">Request Time</th>
                        <th class="p-3 border border-cyan-700">Actions</th>
                    </tr>
                </thead>

                <tbody class="text-white">
                    <%
                        Connection connection = null;
                        PreparedStatement preparedStatement = null;
                        ResultSet resultSet = null;

                        if (uemail == null) {
                            out.println("<tr><td colspan='8' class='text-center p-4 text-red-400'>Please login first!</td></tr>");
                        } else {
                            try {
                                connection = Database.getconnection();
                                String sql = "SELECT * FROM decrypt_requests WHERE uemailid=? AND status='approved'";
                                preparedStatement = connection.prepareStatement(sql);
                                preparedStatement.setString(1, uemail);
                                resultSet = preparedStatement.executeQuery();

                                while (resultSet.next()) {
                                    int id = resultSet.getInt("id");
                                    String filename = resultSet.getString("filename");
                                    String cemailid = resultSet.getString("cemailid");
                                    String encrypted = resultSet.getString("encrypteddata");
                                    String token = resultSet.getString("token");
                                    String status = resultSet.getString("status");
                                    Time reqTime = resultSet.getTime("request_time");
                    %>

                    <tr class="hover:bg-cyan-800/30">
                        <td class="p-3 border border-cyan-700"><%= id %></td>
                        <td class="p-3 border border-cyan-700"><%= filename %></td>
                        <td class="p-3 border border-cyan-700"><%= cemailid %></td>
                        <td class="p-3 border border-cyan-700"><%= encrypted %></td>
                        <td class="p-3 border border-cyan-700"><%= token %></td>
                        <td class="p-3 border border-cyan-700 text-green-300"><%= status %></td>
                        <td class="p-3 border border-cyan-700"><%= reqTime %></td>
                        <td class="p-3 border border-cyan-700 text-center">
                            <a href="KeyReq.jsp?action=approve&id=<%= id %>&filename=<%= filename %>&token=<%= token %>"
                               class="px-3 py-1 bg-green-600 rounded-lg hover:bg-green-700">Approve</a>
                            <a href="KeyReq.jsp?action=reject&id=<%= id %>"
                               class="px-3 py-1 bg-red-600 rounded-lg hover:bg-red-700 ml-2">Reject</a>
                        </td>
                    </tr>

                    <%
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            } finally {
                                try {
                                    if (resultSet != null) resultSet.close();
                                    if (preparedStatement != null) preparedStatement.close();
                                    if (connection != null) connection.close();
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        String action = request.getParameter("action");
                        String id = request.getParameter("id");
                        String filename = request.getParameter("filename");
                        String token = request.getParameter("token");

                        if (action != null && id != null) {
                            try {
                                connection = Database.getconnection();

                                if (action.equals("approve")) {
                                    String keyQuery = "SELECT secret_key FROM uploaded_files WHERE filename=? AND token=?";
                                    PreparedStatement psKey = connection.prepareStatement(keyQuery);
                                    psKey.setString(1, filename);
                                    psKey.setString(2, token);
                                    ResultSet rsKey = psKey.executeQuery();

                                    String secretKeyValue = null;
                                    if (rsKey.next()) {
                                        secretKeyValue = rsKey.getString("secret_key");
                                    }
                                    rsKey.close();
                                    psKey.close();

                                    if (secretKeyValue != null) {
                                        String updateSQL = "UPDATE decrypt_requests SET secret_key=? , status='Key Issued' WHERE id=?";
                                        preparedStatement = connection.prepareStatement(updateSQL);
                                        preparedStatement.setString(1, secretKeyValue);
                                        preparedStatement.setString(2, id);
                                        preparedStatement.executeUpdate();
                                    }

                                    response.sendRedirect("KeyReq.jsp");

                                } else if (action.equals("reject")) {
                                    String rejectSQL = "UPDATE decrypt_requests SET secret_key='rejected' , status='Key Declined' WHERE id=?";
                                    preparedStatement = connection.prepareStatement(rejectSQL);
                                    preparedStatement.setString(1, id);
                                    preparedStatement.executeUpdate();

                                    response.sendRedirect("KeyReq.jsp");
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            } finally {
                                try {
                                    if (preparedStatement != null) preparedStatement.close();
                                    if (connection != null) connection.close();
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    %>

                </tbody>
            </table>
        </div>

    </div>

    <footer class="text-center py-8 opacity-80 mt-14">
        © 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems
    </footer>

</body>

</html>
