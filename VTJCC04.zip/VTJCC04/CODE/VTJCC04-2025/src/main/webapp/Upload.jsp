<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Upload File | Secure Token Attestation</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }

        .card-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,255,255,0.6);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- PROJECT TITLE -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-4">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- Upload Card -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl 
                p-10 mt-10 w-full max-w-xl shadow-2xl text-center">

        <h2 class="text-3xl font-bold text-cyan-300 mb-6">
            Upload a File
        </h2>

        <!-- SUCCESS / ERROR MESSAGE -->
        <% 
            String msg = (String) request.getAttribute("message");
            if (msg != null) {
        %>
            <div class="mb-6 p-4 rounded-xl border border-cyan-400 bg-cyan-500/20 text-cyan-300 font-semibold text-lg shadow-xl">
                <%= msg %>
            </div>
        <% 
            }
        %>

        <form action="Upload" method="POST" enctype="multipart/form-data" class="space-y-6">

            <div class="text-left">
                <label class="block mb-2 font-semibold text-cyan-300">Choose File:</label>
                <input type="file" name="file" required
                       class="w-full p-3 rounded-xl bg-white/10 border border-cyan-400 focus:outline-none">
            </div>

            <div class="text-left">
                <label class="block mb-2 font-semibold text-cyan-300">Custom Filename:</label>
                <input type="text" name="filename" placeholder="Enter your filename" required
                       class="w-full p-3 rounded-xl bg-white/10 border border-cyan-400 focus:outline-none">
            </div>

            <button type="submit"
                class="card-glow w-full py-3 text-xl bg-cyan-500/20 border border-cyan-400 
                       rounded-xl font-semibold hover:bg-cyan-500/30">
                Upload File
            </button>
        </form>
    </div>

    <!-- USER MODULES (Same as UHome.jsp) -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl 
                p-10 mt-10 w-full max-w-2xl shadow-2xl text-center">

        <h2 class="text-3xl font-bold text-cyan-300 mb-6">
            User Modules
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">

            <a href="UHome.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 
                      rounded-xl text-xl font-semibold">
                Home
            </a>

            <a href="Upload.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 
                      rounded-xl text-xl font-semibold">
                Upload a File
            </a>

            <a href="KeyReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 
                      rounded-xl text-xl font-semibold">
                View Decrypt Key Requests
            </a>

            <a href="ULogin.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border border-cyan-400 
                      rounded-xl text-xl font-semibold text-red-300">
                Logout
            </a>

        </div>
    </div>

    <footer class="text-center py-8 opacity-80 mt-14">
        <p>© 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>
</html>
