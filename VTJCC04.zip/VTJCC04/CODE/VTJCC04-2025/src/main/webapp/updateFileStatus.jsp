<%@page import="com.Db.Database"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.Base64" %>
<%@ page import="javax.crypto.*" %>
<%@ page import="javax.crypto.spec.SecretKeySpec" %>
<%@ page import="java.security.*" %>
<%@ page import="java.nio.charset.StandardCharsets" %>
<%
    String id = request.getParameter("id");
    String action = request.getParameter("action");

    Connection con = Database.getconnection();

    String newStatus = "";
    String newKey = "";
    String newToken = "";

    if ("approve".equalsIgnoreCase(action)) {
        // Generate AES secret key
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128);
        SecretKey secretKey = keyGen.generateKey();
        newKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());

        // Generate Property-based Token (PTA)
        String tokenData = id + ":" + newKey + ":" + System.currentTimeMillis();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(tokenData.getBytes(StandardCharsets.UTF_8));
        newToken = Base64.getEncoder().encodeToString(hash).substring(0, 32);

        newStatus = "approved";

    } else if ("reject".equalsIgnoreCase(action)) {
        newKey = "rejected";
        newToken = "rejected";
        newStatus = "rejected";
    }

    String sql = "UPDATE uploaded_files SET secret_key=?, token=?, status=? WHERE id=?";
    PreparedStatement ps = con.prepareStatement(sql);
    ps.setString(1, newKey);
    ps.setString(2, newToken);
    ps.setString(3, newStatus);
    ps.setString(4, id);
    ps.executeUpdate();

    ps.close();
    con.close();
%>

<script>
    alert("File has been <%= newStatus.toUpperCase() %> successfully!");
    window.location = "UploadReq.jsp";
</script>
