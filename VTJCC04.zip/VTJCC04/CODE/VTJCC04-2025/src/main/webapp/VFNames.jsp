<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.Time"%>
<%@page import="com.Db.Database"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
    String cemail = (String) session.getAttribute("cemailid");
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View File Names | Client Module</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }
        .card-glow:hover {
            transform: scale(1.07);
            box-shadow: 0 0 25px rgba(0,255,255,0.7);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- PROJECT TITLE -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-6">
        A Secure Property-Based Token Attestation Framework Using Homomorphic Encryption for Mobile Cloud Systems
    </h1>

    <!-- MAIN CARD -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl p-10 mt-10 
                w-full max-w-5xl shadow-2xl text-center">

        <h2 class="text-3xl font-bold text-cyan-300 mb-4">View File Names</h2>

        <% if (cemail != null) { %>
            <p class="text-xl font-semibold mb-6">
                Logged in as 
                <span class="text-cyan-300"><%= cemail %></span>
            </p>
        <% } %>

        <!-- MODULES MENU -->
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">

            <a href="CHome.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                Home
            </a>

            <a href="Search.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                Search File
            </a>

            <a href="VFNames.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                View File Names
            </a>

            <a href="viewkey.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-cyan-400 rounded-xl text-lg font-semibold">
                View Decryption Keys
            </a>

            <a href="CLogin.jsp"
                class="card-glow bg-white/10 backdrop-blur-xl p-4 text-center 
                border border-red-400 rounded-xl text-lg font-semibold text-red-300">
                Logout
            </a>

        </div>

        <!-- FILE NAMES TABLE -->
        <div class="overflow-x-auto mt-10">
            <table class="w-full border border-cyan-400 text-white text-center rounded-xl">
                <thead class="bg-cyan-500 text-black text-lg">
                    <tr>
                        <th class="p-3">ID</th>
                        <th class="p-3">Filename</th>
                        <th class="p-3">Email ID</th>
                        <th class="p-3">Upload Time</th>
                    </tr>
                </thead>

                <tbody>
                    <%
                        Connection connection = null;
                        PreparedStatement ps = null;
                        ResultSet rs = null;

                        try {
                            connection = Database.getconnection();
                            String sql = "SELECT * FROM uploaded_files WHERE status = 'approved'";
                            ps = connection.prepareStatement(sql);
                            rs = ps.executeQuery();

                            while (rs.next()) {
                                int id = rs.getInt("id");
                                String filename = rs.getString("filename");
                                String emailid = rs.getString("emailid");
                                Time upload = rs.getTime("upload_time");
                    %>

                    <tr class="bg-white/10 border-b border-cyan-300">
                        <td class="p-3"><%= id %></td>
                        <td class="p-3"><%= filename %></td>
                        <td class="p-3"><%= emailid %></td>
                        <td class="p-3"><%= upload %></td>
                    </tr>

                    <%
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                if (rs != null) rs.close();
                                if (ps != null) ps.close();
                                if (connection != null) connection.close();
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                        }
                    %>
                </tbody>
            </table>
        </div>

    </div>

    <footer class="text-center py-8 opacity-80 mt-14">
        <p>© 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>
</html>
