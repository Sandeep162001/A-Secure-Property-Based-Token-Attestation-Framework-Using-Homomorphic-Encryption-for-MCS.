<%@page import="com.Db.Database"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.Statement"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Upload File Requests | TTP Panel</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow {
            transition: 0.3s;
        }

        .card-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,255,255,0.6);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white">

    <!-- PAGE TITLE -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 text-center pt-10 px-4">
        File Upload Requests – Trusted Third Party
    </h1>

    <!-- MODULES SECTION -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl 
                p-10 mt-10 w-full max-w-4xl mx-auto shadow-2xl">

        <h2 class="text-3xl font-bold text-cyan-300 text-center mb-6">
            TTP Modules
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

            <a href="index.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold">
                Home
            </a>

            <a href="URegReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold">
                User Registration Requests
            </a>

            <a href="UploadReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold text-cyan-400">
                File Upload Requests
            </a>

            <a href="CRegReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-cyan-400 rounded-xl text-xl font-semibold">
                Client Registration Requests
            </a>

            <a href="TTPLogin.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center border 
                      border-red-400 rounded-xl text-xl font-semibold text-red-300">
                Logout
            </a>

        </div>
    </div>

    <!-- MAIN CONTENT BOX -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl 
                p-10 mt-12 w-full max-w-6xl mx-auto shadow-2xl">

        <h2 class="text-3xl font-bold text-cyan-300 text-center mb-10">
            Pending File Upload Requests
        </h2>

        <div class="overflow-x-auto">

            <table class="w-full text-white border border-gray-600 rounded-xl overflow-hidden">
                <thead class="bg-cyan-600/30 text-lg">
                    <tr>
                        <th class="p-3 border border-gray-700">ID</th>
                        <th class="p-3 border border-gray-700">Filename</th>
                        <th class="p-3 border border-gray-700">Encrypted Data</th>
                        <th class="p-3 border border-gray-700">Email ID</th>
                        <th class="p-3 border border-gray-700">Status</th>
                        <th class="p-3 border border-gray-700">Uploaded Time</th>
                        <th class="p-3 border border-gray-700">Action</th>
                    </tr>
                </thead>

                <tbody class="text-center">

                <%
                    Connection con = Database.getconnection();
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM uploaded_files WHERE status='pending'");

                    while (rs.next()) {
                        int id = rs.getInt("id");
                        String filename = rs.getString("filename");
                        String encrypted = rs.getString("encrypted_data");
                        String emailid = rs.getString("emailid");
                        String status = rs.getString("status");
                        String uploadTime = rs.getString("upload_time");
                %>

                <tr class="bg-black/20 hover:bg-black/40 transition">
                    <td class="p-3 border border-gray-700"><%= id %></td>
                    <td class="p-3 border border-gray-700"><%= filename %></td>
                    <td class="p-3 border border-gray-700"><%= encrypted %></td>
                    <td class="p-3 border border-gray-700"><%= emailid %></td>
                    <td class="p-3 border border-gray-700 text-yellow-300"><%= status %></td>
                    <td class="p-3 border border-gray-700"><%= uploadTime %></td>

                    <td class="p-3 border border-gray-700">

                        <% if (status.equals("pending")) { %>

                            <form action="updateFileStatus.jsp" method="post" class="inline-block">
                                <input type="hidden" name="id" value="<%= id %>">
                                <input type="hidden" name="action" value="approve">
                                <button class="px-4 py-2 bg-green-500 rounded-lg font-semibold hover:bg-green-600">
                                    Approve
                                </button>
                            </form>

                            <form action="updateFileStatus.jsp" method="post" class="inline-block ml-2">
                                <input type="hidden" name="id" value="<%= id %>">
                                <input type="hidden" name="action" value="reject">
                                <button class="px-4 py-2 bg-red-500 rounded-lg font-semibold hover:bg-red-600">
                                    Reject
                                </button>
                            </form>

                        <% } else { %>

                            <span class="font-bold text-cyan-300"><%= status.toUpperCase() %></span>

                        <% } %>

                    </td>

                </tr>

                <% } %>

                </tbody>
            </table>

        </div>

    </div>

    <footer class="text-center py-8 opacity-80 mt-14">
        <p>© 2025 Secure Token Attestation Framework | TTP Module</p>
    </footer>

</body>
</html>
