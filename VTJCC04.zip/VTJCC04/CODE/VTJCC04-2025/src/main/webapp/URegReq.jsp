<%@page import="java.sql.SQLException"%>
<%@page import="java.sql.Date"%>
<%@page import="com.Db.Database"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@page import="java.util.Random"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Registration Requests | TTP Module</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .gradient-bg {
            background: linear-gradient(-45deg, #0a0a0a, #131344, #05375a, #16697a);
            background-size: 400% 400%;
            animation: gradientAnimation 10s ease infinite;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card-glow { transition: 0.3s; }
        .card-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,255,255,0.6);
        }
    </style>
</head>

<body class="gradient-bg min-h-screen text-white flex flex-col items-center">

    <!-- PAGE TITLE -->
    <h1 class="text-3xl md:text-4xl font-extrabold text-cyan-300 mt-10 text-center px-4">
        User Registration Requests
    </h1>

    <!-- MODULES SECTION -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl 
                p-10 mt-10 w-full max-w-4xl shadow-2xl text-center">

        <h2 class="text-3xl font-bold text-cyan-300 mb-6">TTP Modules</h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

            <a href="TTPHome.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center 
                      border border-cyan-400 rounded-xl text-xl font-semibold">
                Home
            </a>

            <a href="URegReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center 
                      border border-cyan-400 rounded-xl text-xl font-semibold">
                User Registration Requests
            </a>

            <a href="UploadReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center 
                      border border-cyan-400 rounded-xl text-xl font-semibold">
                File Uploaded Requests
            </a>

            <a href="CRegReq.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center 
                      border border-cyan-400 rounded-xl text-xl font-semibold">
                Client Registration Requests
            </a>

            <a href="TTPLogin.jsp"
               class="card-glow bg-white/10 backdrop-blur-xl p-6 text-center 
                      border border-cyan-400 rounded-xl text-xl font-semibold text-red-300">
                Logout
            </a>

        </div>
    </div>

    <!-- DATA TABLE -->
    <div class="bg-white/10 backdrop-blur-xl border border-cyan-400 rounded-2xl 
                p-10 mt-10 w-full max-w-6xl shadow-2xl">

        <h2 class="text-3xl font-bold text-cyan-300 text-center mb-6">
            Pending User Registrations
        </h2>

        <div class="overflow-x-auto">
            <table class="w-full border border-cyan-400 text-white">
                <thead class="bg-cyan-600/40">
                    <tr>
                        <th class="p-3 border">Name</th>
                        <th class="p-3 border">Email ID</th>
                        <th class="p-3 border">Gender</th>
                        <th class="p-3 border">Mobile No</th>
                        <th class="p-3 border">Date of Birth</th>
                        <th class="p-3 border">Address</th>
                        <th class="p-3 border">Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <%
                        Connection connection = null;
                        PreparedStatement preparedStatement = null;
                        ResultSet resultSet = null;

                        try {
                            connection = Database.getconnection();
                            String sql = "SELECT * FROM uregistration WHERE regstatus = 'pending'";
                            preparedStatement = connection.prepareStatement(sql);
                            resultSet = preparedStatement.executeQuery();

                            while (resultSet.next()) {
                                int uid = resultSet.getInt("id");
                                String name = resultSet.getString("name");
                                String emailid = resultSet.getString("emailid");
                                String gender = resultSet.getString("gender");
                                long mobilenumber = resultSet.getLong("mobilenumber");
                                Date dob = resultSet.getDate("dob");
                                String address = resultSet.getString("address");
                    %>
                    <tr class="hover:bg-white/10">
                        <td class="p-3 border"><%= name %></td>
                        <td class="p-3 border"><%= emailid %></td>
                        <td class="p-3 border"><%= gender %></td>
                        <td class="p-3 border"><%= mobilenumber %></td>
                        <td class="p-3 border"><%= dob %></td>
                        <td class="p-3 border"><%= address %></td>
                        <td class="p-3 border text-center">
                            <a href="URegReq.jsp?action=approve&id=<%= uid %>"
                               class="text-green-400 font-bold hover:underline">Approve</a>
                            |
                            <a href="URegReq.jsp?action=reject&id=<%= uid %>"
                               class="text-red-400 font-bold hover:underline">Reject</a>
                        </td>
                    </tr>
                    <%
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                if (resultSet != null) resultSet.close();
                                if (preparedStatement != null) preparedStatement.close();
                                if (connection != null) connection.close();
                            } catch (SQLException e) { e.printStackTrace(); }
                        }

                        // APPROVE / REJECT ACTION
                        String action = request.getParameter("action");
                        String id = request.getParameter("id");

                        if (action != null && id != null) {
                            try {
                                connection = Database.getconnection();

                                if (action.equals("approve")) {
                                    Random rand = new Random();
                                    int tokenNum = 100000 + rand.nextInt(900000);
                                    String token = String.valueOf(tokenNum);

                                    String updateSQL = "UPDATE uregistration SET regstatus = 'approved', token = ? WHERE id = ?";
                                    preparedStatement = connection.prepareStatement(updateSQL);
                                    preparedStatement.setString(1, token);
                                    preparedStatement.setInt(2, Integer.parseInt(id));
                                    preparedStatement.executeUpdate();

                                    response.sendRedirect("URegReq.jsp");

                                } else if (action.equals("reject")) {
                                    String deleteSQL = "DELETE FROM uregistration WHERE id = ?";
                                    preparedStatement = connection.prepareStatement(deleteSQL);
                                    preparedStatement.setInt(1, Integer.parseInt(id));
                                    preparedStatement.executeUpdate();
                                    response.sendRedirect("URegReq.jsp");
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    %>
                </tbody>
            </table>
        </div>

    </div>

    <footer class="text-center py-8 opacity-80 mt-12">
        <p>© 2025 Secure Token Attestation Framework | Designed for Mobile Cloud Systems</p>
    </footer>

</body>
</html>
