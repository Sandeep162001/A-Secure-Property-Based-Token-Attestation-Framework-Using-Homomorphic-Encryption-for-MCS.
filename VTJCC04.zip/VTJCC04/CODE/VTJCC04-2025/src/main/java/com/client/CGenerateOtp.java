package com.client;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Db.Database;

/**
 * Servlet implementation class CGenerateOtp
 */
@WebServlet("/CGenerateOtp")
public class CGenerateOtp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CGenerateOtp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		String email = request.getParameter("emailid");
        String password = request.getParameter("password");
        String token = request.getParameter("token");  
        HttpSession session = request.getSession();

        try (Connection con = Database.getconnection()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM cregistration WHERE emailid = ? AND password = ? AND token = ? AND regstatus = 'approved'");
            ps.setString(1, email);
            ps.setString(2, password);
            ps.setString(3, token);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // ✅ Generate OTP
                int otp = new Random().nextInt(900000) + 100000;
                long otpTime = System.currentTimeMillis();

                // ✅ Store OTP details in session
                session.setAttribute("otp", otp);
                session.setAttribute("otpEmail", email);
                session.setAttribute("otpTime", otpTime);

                // ✅ Send OTP to JSP (for now display it)
                request.setAttribute("otp", String.valueOf(otp));
                request.setAttribute("message", "OTP generated successfully!");
                request.getRequestDispatcher("CLogin.jsp").forward(request, response);
            } else {
                request.setAttribute("message", "Invalid Email, Password, or Token. Please try again.");
                request.getRequestDispatcher("CLogin.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Server error during OTP generation.");
            request.getRequestDispatcher("CLogin.jsp").forward(request, response);
        }
	}

}
