package com.client;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import com.Db.Database;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
/**
 * Servlet implementation class ViewKey
 */
@WebServlet("/ViewKey")
public class ViewKey extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewKey() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		String filename = request.getParameter("filename");
        String token = request.getParameter("token");
        String cemail = (String) request.getSession().getAttribute("cemailid");

        if (cemail == null) {
            response.getWriter().println("Please login first.");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = Database.getconnection();

            // Validate request and get secret key
            String sql = "SELECT secret_key FROM decrypt_requests WHERE filename=? AND token=? AND cemailid=? AND status='Key Issued'";
            ps = con.prepareStatement(sql);
            ps.setString(1, filename);
            ps.setString(2, token);
            ps.setString(3, cemail);
            rs = ps.executeQuery();

            String secretKey = null;

            if (rs.next()) {
                secretKey = rs.getString("secret_key");
            }

            if (secretKey == null) {
                response.getWriter().println("Invalid access!");
                return;
            }

            // Now fetch original data using secret_key
            String sql2 = "SELECT original_data FROM uploaded_files WHERE filename=? AND token=? AND secret_key=?";
            ps = con.prepareStatement(sql2);
            ps.setString(1, filename);
            ps.setString(2, token);
            ps.setString(3, secretKey);
            rs = ps.executeQuery();

            String original = null;

            if (rs.next()) {
                original = rs.getString("original_data");
            }

            if (original == null) {
                response.getWriter().println("Original data not found.");
                return;
            }

            // Prepare PDF response
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=" + filename + ".pdf");

            Document document = new Document();
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            document.add(new Paragraph("Original File Data"));
            document.add(new Paragraph("--------------------------------------------------\n\n"));
            document.add(new Paragraph(original));

            document.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if(rs != null) rs.close(); } catch(Exception e){}
            try { if(ps != null) ps.close(); } catch(Exception e){}
            try { if(con != null) con.close(); } catch(Exception e){}
        }
    }
	

}
