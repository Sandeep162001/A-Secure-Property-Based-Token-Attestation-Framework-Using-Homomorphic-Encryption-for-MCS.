package com.client;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Db.Database;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
/**
 * Servlet implementation class Search
 */
@WebServlet("/Search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		String keyword = request.getParameter("search");
        List<Map<String, String>> files = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                
                con = Database.getconnection();

                String query = "SELECT filename, emailid, token, upload_time, encrypted_data FROM uploaded_files "
                             + "WHERE filename LIKE ? AND status='approved'";
                ps = con.prepareStatement(query);
                ps.setString(1, "%" + keyword + "%");
                rs = ps.executeQuery();

                while (rs.next()) {
                    Map<String, String> file = new HashMap<>();
                    file.put("filename", rs.getString("filename"));
                    file.put("emailid", rs.getString("emailid"));
                    file.put("token", rs.getString("token"));
                    file.put("upload_time", rs.getString("upload_time"));
                    file.put("encrypted_data", rs.getString("encrypted_data"));
                    files.add(file);
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (Exception ignored) {}
                try { if (ps != null) ps.close(); } catch (Exception ignored) {}
                try { if (con != null) con.close(); } catch (Exception ignored) {}
            }
        }

        request.setAttribute("files", files);
        request.setAttribute("keyword", keyword);
        RequestDispatcher rd = request.getRequestDispatcher("Search.jsp");
        rd.forward(request, response);
    }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
