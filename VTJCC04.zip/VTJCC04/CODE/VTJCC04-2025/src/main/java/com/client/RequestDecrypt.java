package com.client;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Db.Database;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
/**
 * Servlet implementation class RequestDecrypt
 */
@WebServlet("/RequestDecrypt")
public class RequestDecrypt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RequestDecrypt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		// Suppose logged-in user email is stored in session
        HttpSession session = request.getSession();
        String cemailid = (String) session.getAttribute("cemailid");

        // If no session, for testing purpose we can set one manually
        if (cemailid == null || cemailid.isEmpty()) {
            response.sendRedirect("CLogin.jsp");
        }

        String filename = request.getParameter("filename");
        String encrypted_data = request.getParameter("encrypted_data");
        String token = request.getParameter("token");

        Connection con = null;
        PreparedStatement ps1 = null, ps2 = null;
        ResultSet rs = null;

        try {
            
            con = Database.getconnection();

            // First, get file owner's email (uemailid) from uploaded_files
            String query1 = "SELECT emailid FROM uploaded_files WHERE filename=? AND token=?";
            ps1 = con.prepareStatement(query1);
            ps1.setString(1, filename);
            ps1.setString(2, token);
            rs = ps1.executeQuery();

            if (rs.next()) {
                String uemailid = rs.getString("emailid");

                // Insert into decrypt_requests
                String query2 = "INSERT INTO decrypt_requests (uemailid, cemailid, filename, encrypteddata, token, status, secret_key) "
                              + "VALUES (?, ?, ?, ?, ?, 'pending', 'pending')";
                ps2 = con.prepareStatement(query2);
                ps2.setString(1, uemailid);
                ps2.setString(2, cemailid);
                ps2.setString(3, filename);
                ps2.setString(4, encrypted_data);
                ps2.setString(5, token);
                ps2.executeUpdate();

                request.setAttribute("message", "Decryption request sent successfully!");
            } else {
                request.setAttribute("message", "File not found or invalid token!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Error while sending decryption request!");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps1 != null) ps1.close(); } catch (Exception ignored) {}
            try { if (ps2 != null) ps2.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }

        RequestDispatcher rd = request.getRequestDispatcher("Search.jsp");
        rd.forward(request, response);
    }
	

}
