package com.Db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {

public static Connection getconnection() throws ClassNotFoundException, SQLException {
		
		String url="jdbc:mysql://localhost:3306/cc04-2025";
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection= DriverManager.getConnection(url,"root","root");
		return connection;
	}
}
