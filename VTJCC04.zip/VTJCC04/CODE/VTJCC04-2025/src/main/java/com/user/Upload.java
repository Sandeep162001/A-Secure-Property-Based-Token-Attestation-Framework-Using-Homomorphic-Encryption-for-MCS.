package com.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Db.Database;

import java.io.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.*;
import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
/**
 * Servlet implementation class Upload
 */
@WebServlet("/Upload")
@MultipartConfig(maxFileSize = 1024 * 1024 * 50)
public class Upload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Upload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		HttpSession session=request.getSession();
		String emailid=(String) session.getAttribute("uemailid");
		response.setContentType("text/html");

        try {
            Part filePart = request.getPart("file");
            String filename = request.getParameter("filename");

            // Read file content as string
            InputStream fileContent = filePart.getInputStream();
            String originalData = new String(fileContent.readAllBytes());

            // Step 1: Generate AES Key (Simulating secret key)
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(128);
            SecretKey secretKey = keyGen.generateKey();
            String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());

            // Step 2: Encrypt file data using AES
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(originalData.getBytes());
            String encryptedData = Base64.getEncoder().encodeToString(encryptedBytes);

            // Step 3: Generate Property-based Token (Attestation)
            String token = generatePTAToken(filename, encodedKey);

            // Step 4: Store everything in DB
            
            try (Connection con = Database.getconnection()) {
                String sql = "INSERT INTO uploaded_files (filename, original_data, encrypted_data, secret_key, token, status, emailid) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, filename);
                ps.setString(2, originalData);
                ps.setString(3, encryptedData);
                ps.setString(4, "pending"); // secret key is pending until approved
                ps.setString(5, "pending"); // token pending
                ps.setString(6, "pending"); // status pending
                ps.setString(7, emailid);
                ps.executeUpdate();
            }

            request.setAttribute("message", "✅ File uploaded & encrypted successfully! Status set to pending.");
            request.getRequestDispatcher("Upload.jsp").forward(request, response);
        } catch (Exception e) {
        	request.setAttribute("message", "❌ Error uploading file: " + e.getMessage());
            request.getRequestDispatcher("Upload.jsp").forward(request, response);
        }
    }

    // Simulate PTA-HE Token Generation
    private String generatePTAToken(String filename, String key) throws Exception {
        String data = filename + ":" + key + ":" + System.currentTimeMillis();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data.getBytes());
        return Base64.getEncoder().encodeToString(hash).substring(0, 32); 
	}

}
