package com.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Db.Database;



/**
 * Servlet implementation class URegistration
 */
@WebServlet("/URegistration")
public class URegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public URegistration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		String name = request.getParameter("name");
        String emailid = request.getParameter("emailid");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        long mobilenumber = Long.parseLong(request.getParameter("number"));
        Date dateofbirth = Date.valueOf(request.getParameter("dob"));
        String address = request.getParameter("address");
        String registrationstatus = "pending";
        String token="pending";
        

        String checkEmailQuery = "SELECT COUNT(*) FROM uregistration WHERE emailid = ?";
        String insertQuery = "INSERT INTO uregistration (name, emailid, password,gender, mobilenumber, dob, address, regstatus,token) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        PreparedStatement checkStmt = null;
        ResultSet rs = null;
        String message = "";

        try {
            connection = Database.getconnection();

            // Check for duplicate email
            checkStmt = connection.prepareStatement(checkEmailQuery);
            checkStmt.setString(1, emailid);
            rs = checkStmt.executeQuery();

            boolean emailExists = false;
            if (rs.next() && rs.getInt(1) > 0) {
                emailExists = true;
            }

            if (emailExists) {
                message = "Error: This email ID is already registered.";
            } else {
                
                preparedStatement = connection.prepareStatement(insertQuery);
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, emailid);
                preparedStatement.setString(3, password);
                preparedStatement.setString(4, gender);
                preparedStatement.setLong(5, mobilenumber);
                preparedStatement.setDate(6, dateofbirth);    
                preparedStatement.setString(7, address);
                preparedStatement.setString(8, registrationstatus);
                preparedStatement.setString(9, token);

                int result = preparedStatement.executeUpdate();
                if (result != 0) {
                    message = "Registration submitted successfully, awaiting approval.";
                } else {
                    message = "Error: Registration failed.";
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            message = "Error: Server error occurred during registration.";
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (checkStmt != null) checkStmt.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Send the message back to the JSP page
        request.setAttribute("message", message);
        request.getRequestDispatcher("URegistration.jsp").forward(request, response);
    }
	

}
