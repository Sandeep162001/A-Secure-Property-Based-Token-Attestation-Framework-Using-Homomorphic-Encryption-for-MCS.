package com.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Db.Database;



/**
 * Servlet implementation class ULogin
 */
@WebServlet("/ULogin")
public class ULogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final long OTP_EXPIRY_MILLIS = 10 * 60 * 1000;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ULogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		String email = request.getParameter("emailid");
        String password = request.getParameter("password");
        String token = request.getParameter("token");
        String otpStr = request.getParameter("otp");

        HttpSession session = request.getSession();
        response.setContentType("text/html");

        Object otpObj = session.getAttribute("otp");
        Object otpEmailObj = session.getAttribute("otpEmail");
        Object otpTimeObj = session.getAttribute("otpTime");

        if (otpObj == null || otpEmailObj == null || otpTimeObj == null) {
            request.setAttribute("message", "OTP not found or session expired. Please try again.");
            request.getRequestDispatcher("ULogin.jsp").forward(request, response);
            return;
        }

        int generatedOtp = (int) otpObj;
        String sessionEmail = otpEmailObj.toString();
        long otpTime = (long) otpTimeObj;

        if (!email.equals(sessionEmail)) {
            request.setAttribute("message", "Entered email does not match OTP-bound email.");
            request.getRequestDispatcher("ULogin.jsp").forward(request, response);
            return;
        }

        if (System.currentTimeMillis() - otpTime > OTP_EXPIRY_MILLIS) {
            session.invalidate();
            request.setAttribute("message", "OTP expired. Please generate a new one.");
            request.getRequestDispatcher("ULogin.jsp").forward(request, response);
            return;
        }

        int enteredOtp;
        try {
            enteredOtp = Integer.parseInt(otpStr);
        } catch (NumberFormatException e) {
            request.setAttribute("message", "Invalid OTP format.");
            request.getRequestDispatcher("ULogin.jsp").forward(request, response);
            return;
        }

        if (enteredOtp != generatedOtp) {
            request.setAttribute("message", "Incorrect OTP entered.");
            request.getRequestDispatcher("ULogin.jsp").forward(request, response);
            return;
        }

        // ✅ OTP is correct — now validate login credentials again
        try (Connection con = Database.getconnection()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM uregistration WHERE emailid = ? AND password = ? AND token = ? AND regstatus = 'approved'");
            ps.setString(1, email);
            ps.setString(2, password);
            ps.setString(3, token);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                session.removeAttribute("otp");
                session.removeAttribute("otpEmail");
                session.removeAttribute("otpTime");
                session.setAttribute("uemailid", email);
                response.sendRedirect("UHome.jsp");
            } else {
                request.setAttribute("message", "Invalid credentials or token mismatch.");
                request.getRequestDispatcher("ULogin.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Server error during login.");
            request.getRequestDispatcher("ULogin.jsp").forward(request, response);
        }
	}

}
